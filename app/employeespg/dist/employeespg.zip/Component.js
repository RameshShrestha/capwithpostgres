sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("employeespg.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map